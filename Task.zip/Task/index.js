const express = require("express");
const app = express();
const axios = require("axios").default;
var config = require('./mongoose/config');

app.get("/register", (req, res) => {
    axios({
        url: "https://localhost:8000/register",
        method: "post",
        headers: {
            'Accept': 'application/json', 
            'Content-Type': 'application/json',
        },
        body: {
            first_name : 'lead_test@subi.com',
            last_name : '123456', 
            email : 'lead_test@subi.com', 
            password : '123456'
        }
    })
        .then(response => {
            res.status(200).json(response.data);
        })
        .catch((err) => {
            res.status(500).json({ message: err });
        });
    });

    app.get("/login", (req, res) => {
        axios({
            url: "https://localhost:8000/login",
            method: "post",
            headers: {
                'Accept': 'application/json', 
                'Content-Type': 'application/json',
            },
            body: {
                'mail' : 'lead_test@subi.com',
                'password' : '123456' 
            }
        
        })
            .then(response => {
                res.status(200).json(response.data);
            })
            .catch((err) => {
                res.status(500).json({ message: err });
            });
        });
        app.get("/template", (req, res) => {
            axios({
                url: "https://localhost:8000/template",
                method: "post",
                headers: {
                    'Authorization': 'Bearer ' + "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyNGQyYWFkMGQ4OGJlMWI3YjMyYmY1NiIsInJvbGVzIjpbeyJpZCI6IjVlMTk2MjUwNWVmNjEyMDAwODlmM2IyMiJ9XSwicGVybWlzc2lvbnMiOltdLCJhY2NvdW50aWQiOiI2MjRkMmFhZDNiYjU1NzAwMDkxMjlkZGYiLCJhY2NvdW50SWQiOm51bGwsInVzZXJUeXBlIjp7ImtpbmQiOiJSRUdJU1RFUkVEIn0sImlzc3VlciI6IjQ2ODEwMTM5NTIwMyIsImlhdCI6MTY0OTIyNDM2NSwiZXhwIjoxNjQ5MjI2MTY1fQ.IGZparPNKWaHUohuoAdsgWJupFf0ZpyjrmUEVrXGQmyW92HUoD0Beukv-3Bcjbx_kHi3ic90NPKbCDU51NI2g6RFBzaY-1tg20oYZ9nqXwW2Wg_zNI3yckhShkc-Zx2DyLBBA3Apc98ddeCPb8sRC99_y9hU2Bh7OPL9ok7LlKY",
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                },
                body: {
                    'template_name': "Template",
                    'subject': 'Insert new template',
                    'body': "", 
                }
            
            })
        });
            app.get("/template", (req, res) => {
                axios({
                    url: "https://localhost:8000/template",
                    method: "get",
                    headers: {
                        'Authorization': 'Bearer ' + "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyNGQyYWFkMGQ4OGJlMWI3YjMyYmY1NiIsInJvbGVzIjpbeyJpZCI6IjVlMTk2MjUwNWVmNjEyMDAwODlmM2IyMiJ9XSwicGVybWlzc2lvbnMiOltdLCJhY2NvdW50aWQiOiI2MjRkMmFhZDNiYjU1NzAwMDkxMjlkZGYiLCJhY2NvdW50SWQiOm51bGwsInVzZXJUeXBlIjp7ImtpbmQiOiJSRUdJU1RFUkVEIn0sImlzc3VlciI6IjQ2ODEwMTM5NTIwMyIsImlhdCI6MTY0OTIyNDM2NSwiZXhwIjoxNjQ5MjI2MTY1fQ.IGZparPNKWaHUohuoAdsgWJupFf0ZpyjrmUEVrXGQmyW92HUoD0Beukv-3Bcjbx_kHi3ic90NPKbCDU51NI2g6RFBzaY-1tg20oYZ9nqXwW2Wg_zNI3yckhShkc-Zx2DyLBBA3Apc98ddeCPb8sRC99_y9hU2Bh7OPL9ok7LlKY",
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: {
                        
                            "username": "venkatalakshmi",
                            "password": "Venkey@123"
                            
                            
                    }
                
                })
                   
                .then(response => {
                    res.status(200).json(response.data);
                })
                .catch((err) => {
                    res.status(500).json({ message: err });
                });
            });
            app.get("/template/id", (req, res) => {
                axios({
                    url: "https://localhost:8000/template/id",
                    method: "get",
                    headers: {
                        'Authorization': 'Bearer ' + "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyNGQyYWFkMGQ4OGJlMWI3YjMyYmY1NiIsInJvbGVzIjpbeyJpZCI6IjVlMTk2MjUwNWVmNjEyMDAwODlmM2IyMiJ9XSwicGVybWlzc2lvbnMiOltdLCJhY2NvdW50aWQiOiI2MjRkMmFhZDNiYjU1NzAwMDkxMjlkZGYiLCJhY2NvdW50SWQiOm51bGwsInVzZXJUeXBlIjp7ImtpbmQiOiJSRUdJU1RFUkVEIn0sImlzc3VlciI6IjQ2ODEwMTM5NTIwMyIsImlhdCI6MTY0OTIyNDM2NSwiZXhwIjoxNjQ5MjI2MTY1fQ.IGZparPNKWaHUohuoAdsgWJupFf0ZpyjrmUEVrXGQmyW92HUoD0Beukv-3Bcjbx_kHi3ic90NPKbCDU51NI2g6RFBzaY-1tg20oYZ9nqXwW2Wg_zNI3yckhShkc-Zx2DyLBBA3Apc98ddeCPb8sRC99_y9hU2Bh7OPL9ok7LlKY",
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: {
                            "id": "5", 
                            "username": "venkatalakshmi",
                            "password": "Venkey@123"
                            
                            
                    }
                
                })
                   
                .then(response => {
                    res.status(200).json(response.data);
                })
                .catch((err) => {
                    res.status(500).json({ message: err });
                });
            });
            app.get("/template/id", (req, res) => {
                axios({
                    url: "https://localhost:8000/update/template/id",
                    method: "put",
                    headers: {
                        'Authorization': 'Bearer ' + "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyNGQyYWFkMGQ4OGJlMWI3YjMyYmY1NiIsInJvbGVzIjpbeyJpZCI6IjVlMTk2MjUwNWVmNjEyMDAwODlmM2IyMiJ9XSwicGVybWlzc2lvbnMiOltdLCJhY2NvdW50aWQiOiI2MjRkMmFhZDNiYjU1NzAwMDkxMjlkZGYiLCJhY2NvdW50SWQiOm51bGwsInVzZXJUeXBlIjp7ImtpbmQiOiJSRUdJU1RFUkVEIn0sImlzc3VlciI6IjQ2ODEwMTM5NTIwMyIsImlhdCI6MTY0OTIyNDM2NSwiZXhwIjoxNjQ5MjI2MTY1fQ.IGZparPNKWaHUohuoAdsgWJupFf0ZpyjrmUEVrXGQmyW92HUoD0Beukv-3Bcjbx_kHi3ic90NPKbCDU51NI2g6RFBzaY-1tg20oYZ9nqXwW2Wg_zNI3yckhShkc-Zx2DyLBBA3Apc98ddeCPb8sRC99_y9hU2Bh7OPL9ok7LlKY",
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: { 
                    'template_name': "Update Template",
                    'subject': 'Update single template',
                    'body': {
                        "username": "venkatalakshmi",
                        "password": "Venkey@123"
                            
                    }
                }
                
                })
                   
                .then(response => {
                    res.status(200).json(response.data);
                })
                .catch((err) => {
                    res.status(500).json({ message: err });
                });
            });
            app.get("/template/id", (req, res) => {
                axios({
                    url: "https://localhost:8000/delete/template/id",
                    method: "delete",
                    headers: {
                        'Authorization': 'Bearer ' + "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjYyNGQyYWFkMGQ4OGJlMWI3YjMyYmY1NiIsInJvbGVzIjpbeyJpZCI6IjVlMTk2MjUwNWVmNjEyMDAwODlmM2IyMiJ9XSwicGVybWlzc2lvbnMiOltdLCJhY2NvdW50aWQiOiI2MjRkMmFhZDNiYjU1NzAwMDkxMjlkZGYiLCJhY2NvdW50SWQiOm51bGwsInVzZXJUeXBlIjp7ImtpbmQiOiJSRUdJU1RFUkVEIn0sImlzc3VlciI6IjQ2ODEwMTM5NTIwMyIsImlhdCI6MTY0OTIyNDM2NSwiZXhwIjoxNjQ5MjI2MTY1fQ.IGZparPNKWaHUohuoAdsgWJupFf0ZpyjrmUEVrXGQmyW92HUoD0Beukv-3Bcjbx_kHi3ic90NPKbCDU51NI2g6RFBzaY-1tg20oYZ9nqXwW2Wg_zNI3yckhShkc-Zx2DyLBBA3Apc98ddeCPb8sRC99_y9hU2Bh7OPL9ok7LlKY",
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                    },
                    body: {
                            "id": "8",
                            "username": "venka@gmail.com",
                            "password": "Venkey123@123"
                            
                            
                    }
                
                })
                   
                .then(response => {
                    res.status(200).json(response.data);
                })
                .catch((err) => {
                    res.status(500).json({ message: err });
                });
            });    
        
        
app.listen(8000, () => {
    console.log("Server started at port 8000");
});
